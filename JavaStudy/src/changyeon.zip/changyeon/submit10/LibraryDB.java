package changyeon.submit10;

import java.util.ArrayList;

public class LibraryDB {
	
	ArrayList<Book> bookList = new ArrayList<>();
	
	private LibraryDB() {}
	
	
	
	static LibraryDB instance = new LibraryDB();
	
	public static LibraryDB getInstance() {
		return instance;
	}
	
	// 책 번호 메소드
	public int makeNum() {
		return bookList.size() + 1;
	}
	
	public void maketitle(Book book) {
		bookList.add(book);
	}
	
	public void showBookList() {
		for(int i=0; i < bookList.size(); i++) {
			System.out.println(bookList.get(i));
		}
	}
	
}
